package com.app.hospital.DTO;

import lombok.Data;

@Data
public class signuprequest {

    private String username; 
    private String name; 
    private String password; 
    private String email; 
    private String phone; 
 
    // Getters and Setters
}
