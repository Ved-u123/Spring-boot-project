package com.app.hospital.DTO;

import lombok.Data;

@Data
public class loginrequest {
    private String username; 
    private String password; 
 
    // Getters and Setters
}
