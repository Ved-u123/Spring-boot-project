package com.app.hospital.DTO;

public class jwtresponse {
    public jwtresponse(String token) {
        //TODO Auto-generated constructor stub
    }

    public class JwtResponse { 
    private String token; 
 
    public JwtResponse(String token) { 
        this.token = token; 
    } 
 
    public String getToken() { 
        return token; 
    } 
}
}
